#!/bin/bash
# 保守清理脚本 - 只删除明确过时的文件

BASE_DIR="/Users/cradle/Documents/GitHub/SC4020IBS/src/LY-Results"

echo "======================================"
echo "开始保守清理..."
echo "======================================"
echo ""

# 记录删除的文件
DELETED_COUNT=0

# 1. 清理 analysis/ 旧文件（保留Newest/）
echo "1. 清理 analysis/ 旧文件..."
cd "$BASE_DIR/analysis"

FILES_TO_DELETE=(
    "analysis_report_en.md"
    "analysis_report.md"
    "lsh_parameter_analysis_en.csv"
    "lsh_parameter_analysis.csv"
    "lsh_parameter_analysis.png"
    "scalability_analysis_en.csv"
    "scalability_analysis.csv"
    "scalability_analysis.png"
)

for file in "${FILES_TO_DELETE[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ 删除: $file"
        rm -f "$file"
        ((DELETED_COUNT++))
    fi
done

echo ""

# 2. 清理 results/optimization/ 中文版图表
echo "2. 清理 results/optimization/ 中文版图表..."
cd "$BASE_DIR/results/optimization"

CN_CHARTS=(
    "lsh_optimization_visualization.png"
    "lsh_parameter_trends.png"
    "pca_lsh_analysis.png"
)

for file in "${CN_CHARTS[@]}"; do
    if [ -f "$file" ]; then
        echo "  ✓ 删除: $file"
        rm -f "$file"
        ((DELETED_COUNT++))
    fi
done

echo ""

# 3. 清理 results/Nah-Problem_Resolve/ 目录
echo "3. 清理 results/Nah-Problem_Resolve/ 旧问题诊断目录..."
cd "$BASE_DIR/results"

if [ -d "Nah-Problem_Resolve" ]; then
    echo "  ✓ 删除整个目录: Nah-Problem_Resolve/"
    rm -rf "Nah-Problem_Resolve"
    ((DELETED_COUNT+=5))  # 估计该目录有5个文件
fi

echo ""
echo "======================================"
echo "清理完成！"
echo "======================================"
echo "共删除: $DELETED_COUNT 个文件/目录"
echo ""
echo "✅ 保留的重要文件:"
echo "  - code/ 所有文件（未删除任何代码）"
echo "  - analysis/Newest/ （最新分析报告）"
echo "  - results/optimization/ 英文版图表"
echo "  - results/analysis/ 深度分析结果"
echo ""
echo "🗑️ 已删除:"
echo "  - analysis/ 旧报告（8个文件）"
echo "  - 中文版图表（3个文件）"
echo "  - Nah-Problem_Resolve/ 目录"
echo ""
echo "💾 备份文件位置:"
echo "  /Users/cradle/Documents/GitHub/SC4020IBS/src/LY-Results-backup-*.tar.gz"
echo "======================================"

