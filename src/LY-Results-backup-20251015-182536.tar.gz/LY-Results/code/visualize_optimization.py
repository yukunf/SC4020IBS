"""
可视化LSH优化效果 (中英文版本)
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import os
import sys
from typing import Dict, List
from collections import defaultdict
from tqdm import tqdm
import time

# 导入LSH相关类
sys.path.append(os.path.dirname(__file__))
try:
    from lsh_search import LSHIndex
except ImportError:
    print("Warning: LSHIndex not found. Candidate set analysis will be skipped.")
    LSHIndex = None

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 优化结果数据
results = {
    '配置': ['原始LSH\n(10表,12位)', '优化v1\n(40表,8位,3探针)', '优化v2\n(50表,6位,5探针)', '优化v3\n(30表,8位,4探针)'],
    '准确率@50(%)': [3.07, 6.92, 14.32, 7.45],
    '查询时间(ms)': [0.24, 9.12, 16.70, 8.70],
    '提升(%)': [0, 3.85, 11.25, 4.38],
    '哈希表数': [10, 40, 50, 30],
    '哈希位数': [12, 8, 6, 8],
    '探针数': [0, 3, 5, 4]
}

df = pd.DataFrame(results)

# 创建综合对比图
fig = plt.figure(figsize=(18, 10))

# 1. 准确率对比（柱状图）
ax1 = plt.subplot(2, 3, 1)
colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
bars = ax1.bar(range(len(df)), df['准确率@50(%)'], color=colors, alpha=0.8, edgecolor='black')
ax1.set_xticks(range(len(df)))
ax1.set_xticklabels(df['配置'], fontsize=9)
ax1.set_ylabel('准确率@50 (%)', fontsize=11, fontweight='bold')
ax1.set_title('准确率对比', fontsize=12, fontweight='bold')
ax1.grid(axis='y', alpha=0.3)

# 在柱子上标注数值
for i, bar in enumerate(bars):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height,
            f'{height:.2f}%',
            ha='center', va='bottom', fontsize=10, fontweight='bold')

# 标注最佳
best_idx = df['准确率@50(%)'].idxmax()
ax1.text(best_idx, df.loc[best_idx, '准确率@50(%)'] + 0.5, '🏆 最佳',
        ha='center', fontsize=11, fontweight='bold', color='red')

# 2. 查询时间对比（柱状图）
ax2 = plt.subplot(2, 3, 2)
bars = ax2.bar(range(len(df)), df['查询时间(ms)'], color=colors, alpha=0.8, edgecolor='black')
ax2.set_xticks(range(len(df)))
ax2.set_xticklabels(df['配置'], fontsize=9)
ax2.set_ylabel('查询时间 (ms)', fontsize=11, fontweight='bold')
ax2.set_title('查询时间对比', fontsize=12, fontweight='bold')
ax2.grid(axis='y', alpha=0.3)

for i, bar in enumerate(bars):
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height,
            f'{height:.2f}',
            ha='center', va='bottom', fontsize=10)

# 3. 准确率提升（柱状图）
ax3 = plt.subplot(2, 3, 3)
bars = ax3.bar(range(len(df)), df['提升(%)'], color=colors, alpha=0.8, edgecolor='black')
ax3.set_xticks(range(len(df)))
ax3.set_xticklabels(df['配置'], fontsize=9)
ax3.set_ylabel('准确率提升 (%)', fontsize=11, fontweight='bold')
ax3.set_title('相比原始LSH的提升', fontsize=12, fontweight='bold')
ax3.grid(axis='y', alpha=0.3)

for i, bar in enumerate(bars):
    height = bar.get_height()
    if height > 0:
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'+{height:.2f}%',
                ha='center', va='bottom', fontsize=10, fontweight='bold', color='green')

# 4. 准确率 vs 查询时间（散点图）
ax4 = plt.subplot(2, 3, 4)
scatter = ax4.scatter(df['查询时间(ms)'], df['准确率@50(%)'], 
                     s=300, c=colors, alpha=0.6, edgecolors='black', linewidth=2)

for i, txt in enumerate(df['配置']):
    ax4.annotate(txt, (df.loc[i, '查询时间(ms)'], df.loc[i, '准确率@50(%)']),
                fontsize=8, ha='center', va='bottom')

ax4.set_xlabel('查询时间 (ms)', fontsize=11, fontweight='bold')
ax4.set_ylabel('准确率@50 (%)', fontsize=11, fontweight='bold')
ax4.set_title('准确率-速度权衡分析', fontsize=12, fontweight='bold')
ax4.grid(True, alpha=0.3)

# 标注帕累托前沿
ax4.axhline(y=df['准确率@50(%)'].max(), color='r', linestyle='--', alpha=0.3, label='最高准确率')
ax4.axvline(x=df['查询时间(ms)'].min(), color='b', linestyle='--', alpha=0.3, label='最快速度')
ax4.legend(fontsize=9)

# 5. 参数配置热力图
ax5 = plt.subplot(2, 3, 5)
param_data = df[['哈希表数', '哈希位数', '探针数']].T
sns.heatmap(param_data, annot=True, fmt='g', cmap='YlOrRd', 
           xticklabels=[f"配置{i+1}" for i in range(len(df))],
           yticklabels=['哈希表数', '哈希位数', '探针数'],
           cbar_kws={'label': '参数值'}, ax=ax5)
ax5.set_title('参数配置对比', fontsize=12, fontweight='bold')

# 6. 相对性能雷达图
ax6 = plt.subplot(2, 3, 6, projection='polar')

# 归一化数据（准确率越高越好，时间越低越好）
metrics = ['准确率\n(越高越好)', '速度\n(越快越好)', '效率\n(准确率/时间)']
angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
angles += angles[:1]

for i in range(len(df)):
    values = [
        df.loc[i, '准确率@50(%)'] / df['准确率@50(%)'].max() * 100,  # 准确率归一化
        (1 / df.loc[i, '查询时间(ms)']) / (1 / df['查询时间(ms)']).max() * 100,  # 速度归一化（倒数）
        (df.loc[i, '准确率@50(%)'] / df.loc[i, '查询时间(ms)']) / 
        (df['准确率@50(%)'] / df['查询时间(ms)']).max() * 100  # 效率归一化
    ]
    values += values[:1]
    
    ax6.plot(angles, values, 'o-', linewidth=2, label=df.loc[i, '配置'], color=colors[i])
    ax6.fill(angles, values, alpha=0.15, color=colors[i])

ax6.set_xticks(angles[:-1])
ax6.set_xticklabels(metrics, fontsize=9)
ax6.set_ylim(0, 100)
ax6.set_title('综合性能雷达图', fontsize=12, fontweight='bold', pad=20)
ax6.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)
ax6.grid(True)

plt.suptitle('LSH优化效果全面对比 - DeepFashion数据集', 
            fontsize=16, fontweight='bold', y=0.98)

plt.tight_layout()

# 保存图表
os.makedirs('results/optimization', exist_ok=True)
plt.savefig('results/optimization/lsh_optimization_visualization.png', 
           dpi=300, bbox_inches='tight', facecolor='white')
print("可视化图表已保存到: results/optimization/lsh_optimization_visualization.png")

# 创建第二张图：详细趋势分析
fig2, axes = plt.subplots(2, 2, figsize=(14, 10))

# 1. 哈希表数量 vs 准确率
axes[0, 0].plot(df['哈希表数'], df['准确率@50(%)'], 'o-', linewidth=2, markersize=10, color='#4ECDC4')
axes[0, 0].set_xlabel('哈希表数量', fontsize=11, fontweight='bold')
axes[0, 0].set_ylabel('准确率@50 (%)', fontsize=11, fontweight='bold')
axes[0, 0].set_title('哈希表数量 vs 准确率', fontsize=12, fontweight='bold')
axes[0, 0].grid(True, alpha=0.3)
for i in range(len(df)):
    axes[0, 0].annotate(f"{df.loc[i, '准确率@50(%)']:.2f}%", 
                       (df.loc[i, '哈希表数'], df.loc[i, '准确率@50(%)']),
                       textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)

# 2. 哈希位数 vs 准确率（关键发现！）
axes[0, 1].plot(df['哈希位数'], df['准确率@50(%)'], 'o-', linewidth=2, markersize=10, color='#FF6B6B')
axes[0, 1].set_xlabel('哈希位数', fontsize=11, fontweight='bold')
axes[0, 1].set_ylabel('准确率@50 (%)', fontsize=11, fontweight='bold')
axes[0, 1].set_title('哈希位数 vs 准确率（负相关！）', fontsize=12, fontweight='bold')
axes[0, 1].grid(True, alpha=0.3)
axes[0, 1].invert_xaxis()  # 反转x轴强调负相关
for i in range(len(df)):
    axes[0, 1].annotate(f"{df.loc[i, '准确率@50(%)']:.2f}%", 
                       (df.loc[i, '哈希位数'], df.loc[i, '准确率@50(%)']),
                       textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)
axes[0, 1].text(0.5, 0.95, '⚠️ 关键发现：哈希位数越小，准确率越高！', 
               transform=axes[0, 1].transAxes, ha='center', va='top',
               fontsize=10, bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.5))

# 3. 探针数 vs 准确率
axes[1, 0].plot(df['探针数'], df['准确率@50(%)'], 'o-', linewidth=2, markersize=10, color='#45B7D1')
axes[1, 0].set_xlabel('探针数（Multi-Probe）', fontsize=11, fontweight='bold')
axes[1, 0].set_ylabel('准确率@50 (%)', fontsize=11, fontweight='bold')
axes[1, 0].set_title('探针数 vs 准确率', fontsize=12, fontweight='bold')
axes[1, 0].grid(True, alpha=0.3)
for i in range(len(df)):
    axes[1, 0].annotate(f"{df.loc[i, '准确率@50(%)']:.2f}%", 
                       (df.loc[i, '探针数'], df.loc[i, '准确率@50(%)']),
                       textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)

# 4. 综合指标对比表
axes[1, 1].axis('off')
table_data = []
for i in range(len(df)):
    table_data.append([
        df.loc[i, '配置'].replace('\n', ' '),
        f"{df.loc[i, '准确率@50(%)']:.2f}%",
        f"{df.loc[i, '查询时间(ms)']:.2f} ms",
        f"{df.loc[i, '提升(%)']:+.2f}%",
        '🏆' if i == best_idx else ''
    ])

table = axes[1, 1].table(cellText=table_data,
                        colLabels=['配置', '准确率', '查询时间', '提升', ''],
                        cellLoc='center',
                        loc='center',
                        bbox=[0, 0, 1, 1])
table.auto_set_font_size(False)
table.set_fontsize(9)
table.scale(1, 2)

# 设置表头样式
for i in range(5):
    table[(0, i)].set_facecolor('#4ECDC4')
    table[(0, i)].set_text_props(weight='bold', color='white')

# 高亮最佳行
for i in range(5):
    table[(best_idx + 1, i)].set_facecolor('#FFE66D')

axes[1, 1].set_title('详细性能对比表', fontsize=12, fontweight='bold', pad=20)

plt.suptitle('LSH参数影响趋势分析', fontsize=16, fontweight='bold', y=0.98)
plt.tight_layout()

plt.savefig('results/optimization/lsh_parameter_trends.png', 
           dpi=300, bbox_inches='tight', facecolor='white')
print("参数趋势图已保存到: results/optimization/lsh_parameter_trends.png")

plt.show()

print("\n" + "="*60)
print("可视化完成！生成了两张图表：")
print("1. lsh_optimization_visualization.png - 综合对比图")
print("2. lsh_parameter_trends.png - 参数趋势分析图")
print("="*60)


# ============================================================================
# 英文版本生成函数
# ============================================================================

def generate_candidate_set_analysis_en(vectors_path=None):
    """生成候选集大小与性能关系分析 (English Version)"""
    
    if LSHIndex is None or vectors_path is None or not os.path.exists(vectors_path):
        print("Skipping candidate set analysis - missing dependencies or data")
        return None
    
    print("\n=== Generating Candidate Set Analysis (English) ===")
    
    # 加载数据
    vectors = np.load(vectors_path)
    print(f"Loaded {len(vectors)} vectors of dimension {vectors.shape[1]}")
    
    # 定义测试配置
    configs = [
        {'name': 'Original LSH\n(10T,12B)', 'num_tables': 10, 'hash_size': 12, 'probes': 0},
        {'name': 'Optimized v1\n(40T,8B,3P)', 'num_tables': 40, 'hash_size': 8, 'probes': 3},
        {'name': 'Optimized v2\n(50T,6B,5P)', 'num_tables': 50, 'hash_size': 6, 'probes': 5},
        {'name': 'Optimized v3\n(30T,8B,4P)', 'num_tables': 30, 'hash_size': 8, 'probes': 4},
    ]
    
    # 准确率数据（从已知结果）
    accuracies = [3.07, 6.92, 14.32, 7.45]
    query_times = [0.24, 9.12, 16.70, 8.70]
    
    # 分析候选集大小
    results = []
    test_queries = vectors[np.random.choice(len(vectors), 100, replace=False)]
    
    for i, config in enumerate(configs):
        lsh = LSHIndex(hash_family='random_projection',
                      num_tables=config['num_tables'],
                      hash_size=config['hash_size'])
        lsh.build_index(vectors)
        
        candidate_sizes = []
        for query in test_queries:
            candidates = lsh._get_candidates(query)
            candidate_sizes.append(len(candidates))
        
        avg_candidate_size = np.mean(candidate_sizes)
        candidate_ratio = (avg_candidate_size / len(vectors)) * 100  # 候选集占比
        
        results.append({
            'config': config['name'],
            'num_tables': config['num_tables'],
            'hash_size': config['hash_size'],
            'avg_candidate_size': avg_candidate_size,
            'candidate_ratio': candidate_ratio,
            'accuracy': accuracies[i],
            'query_time': query_times[i]
        })
        
        print(f"{config['name']}: Avg candidate size = {avg_candidate_size:.0f} ({candidate_ratio:.1f}%)")
    
    return pd.DataFrame(results)


def visualize_english_version(candidate_df=None):
    """生成英文版本的可视化"""
    
    print("\n=== Generating English Version Visualizations ===")
    
    # English version data
    results_en = {
        'Config': ['Original LSH\n(10T,12B)', 'Opt v1\n(40T,8B,3P)', 'Opt v2\n(50T,6B,5P)', 'Opt v3\n(30T,8B,4P)'],
        'Accuracy@50(%)': [3.07, 6.92, 14.32, 7.45],
        'Query Time(ms)': [0.24, 9.12, 16.70, 8.70],
        'Improvement(%)': [0, 3.85, 11.25, 4.38],
        'Num Tables': [10, 40, 50, 30],
        'Hash Bits': [12, 8, 6, 8],
        'Probes': [0, 3, 5, 4]
    }
    
    df_en = pd.DataFrame(results_en)
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A']
    
    # ========================================================================
    # 图1: 综合对比图（英文版）
    # ========================================================================
    fig = plt.figure(figsize=(18, 10))
    
    # 1. Accuracy comparison
    ax1 = plt.subplot(2, 3, 1)
    bars = ax1.bar(range(len(df_en)), df_en['Accuracy@50(%)'], color=colors, alpha=0.8, edgecolor='black')
    ax1.set_xticks(range(len(df_en)))
    ax1.set_xticklabels(df_en['Config'], fontsize=9)
    ax1.set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
    ax1.set_title('Accuracy Comparison', fontsize=12, fontweight='bold')
    ax1.grid(axis='y', alpha=0.3)
    
    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    best_idx = df_en['Accuracy@50(%)'].idxmax()
    ax1.text(best_idx, df_en.loc[best_idx, 'Accuracy@50(%)'] + 0.5, '🏆 Best',
            ha='center', fontsize=11, fontweight='bold', color='red')
    
    # 2. Query time comparison
    ax2 = plt.subplot(2, 3, 2)
    bars = ax2.bar(range(len(df_en)), df_en['Query Time(ms)'], color=colors, alpha=0.8, edgecolor='black')
    ax2.set_xticks(range(len(df_en)))
    ax2.set_xticklabels(df_en['Config'], fontsize=9)
    ax2.set_ylabel('Query Time (ms)', fontsize=11, fontweight='bold')
    ax2.set_title('Query Time Comparison', fontsize=12, fontweight='bold')
    ax2.grid(axis='y', alpha=0.3)
    
    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}', ha='center', va='bottom', fontsize=10)
    
    # 3. Improvement over baseline
    ax3 = plt.subplot(2, 3, 3)
    bars = ax3.bar(range(len(df_en)), df_en['Improvement(%)'], color=colors, alpha=0.8, edgecolor='black')
    ax3.set_xticks(range(len(df_en)))
    ax3.set_xticklabels(df_en['Config'], fontsize=9)
    ax3.set_ylabel('Accuracy Improvement (%)', fontsize=11, fontweight='bold')
    ax3.set_title('Improvement over Original LSH', fontsize=12, fontweight='bold')
    ax3.grid(axis='y', alpha=0.3)
    
    for i, bar in enumerate(bars):
        height = bar.get_height()
        if height > 0:
            ax3.text(bar.get_x() + bar.get_width()/2., height,
                    f'+{height:.2f}%', ha='center', va='bottom', fontsize=10, fontweight='bold', color='green')
    
    # 4. Accuracy vs Query Time scatter
    ax4 = plt.subplot(2, 3, 4)
    scatter = ax4.scatter(df_en['Query Time(ms)'], df_en['Accuracy@50(%)'], 
                         s=300, c=colors, alpha=0.6, edgecolors='black', linewidth=2)
    
    for i, txt in enumerate(df_en['Config']):
        ax4.annotate(txt, (df_en.loc[i, 'Query Time(ms)'], df_en.loc[i, 'Accuracy@50(%)']),
                    fontsize=8, ha='center', va='bottom')
    
    ax4.set_xlabel('Query Time (ms)', fontsize=11, fontweight='bold')
    ax4.set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
    ax4.set_title('Accuracy-Speed Tradeoff', fontsize=12, fontweight='bold')
    ax4.grid(True, alpha=0.3)
    ax4.axhline(y=df_en['Accuracy@50(%)'].max(), color='r', linestyle='--', alpha=0.3, label='Highest Accuracy')
    ax4.axvline(x=df_en['Query Time(ms)'].min(), color='b', linestyle='--', alpha=0.3, label='Fastest Speed')
    ax4.legend(fontsize=9)
    
    # 5. Parameter heatmap
    ax5 = plt.subplot(2, 3, 5)
    param_data = df_en[['Num Tables', 'Hash Bits', 'Probes']].T
    sns.heatmap(param_data, annot=True, fmt='g', cmap='YlOrRd', 
               xticklabels=[f"Config{i+1}" for i in range(len(df_en))],
               yticklabels=['Num Tables', 'Hash Bits', 'Probes'],
               cbar_kws={'label': 'Parameter Value'}, ax=ax5)
    ax5.set_title('Parameter Configuration Comparison', fontsize=12, fontweight='bold')
    
    # 6. Performance radar chart
    ax6 = plt.subplot(2, 3, 6, projection='polar')
    metrics = ['Accuracy\n(Higher Better)', 'Speed\n(Faster Better)', 'Efficiency\n(Acc/Time)']
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
    angles += angles[:1]
    
    for i in range(len(df_en)):
        values = [
            df_en.loc[i, 'Accuracy@50(%)'] / df_en['Accuracy@50(%)'].max() * 100,
            (1 / df_en.loc[i, 'Query Time(ms)']) / (1 / df_en['Query Time(ms)']).max() * 100,
            (df_en.loc[i, 'Accuracy@50(%)'] / df_en.loc[i, 'Query Time(ms)']) / 
            (df_en['Accuracy@50(%)'] / df_en['Query Time(ms)']).max() * 100
        ]
        values += values[:1]
        
        ax6.plot(angles, values, 'o-', linewidth=2, label=df_en.loc[i, 'Config'], color=colors[i])
        ax6.fill(angles, values, alpha=0.15, color=colors[i])
    
    ax6.set_xticks(angles[:-1])
    ax6.set_xticklabels(metrics, fontsize=9)
    ax6.set_ylim(0, 100)
    ax6.set_title('Overall Performance Radar Chart', fontsize=12, fontweight='bold', pad=20)
    ax6.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=8)
    ax6.grid(True)
    
    plt.suptitle('LSH Optimization Comprehensive Comparison - DeepFashion Dataset', 
                fontsize=16, fontweight='bold', y=0.98)
    plt.tight_layout()
    
    plt.savefig('results/optimization/lsh_optimization_visualization_en.png', 
               dpi=300, bbox_inches='tight', facecolor='white')
    print("✓ Saved: results/optimization/lsh_optimization_visualization_en.png")
    
    # ========================================================================
    # 图2: 参数趋势分析（英文版）
    # ========================================================================
    fig2, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # 1. Num Tables vs Accuracy
    axes[0, 0].plot(df_en['Num Tables'], df_en['Accuracy@50(%)'], 'o-', linewidth=2, markersize=10, color='#4ECDC4')
    axes[0, 0].set_xlabel('Number of Hash Tables', fontsize=11, fontweight='bold')
    axes[0, 0].set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
    axes[0, 0].set_title('Number of Hash Tables vs Accuracy', fontsize=12, fontweight='bold')
    axes[0, 0].grid(True, alpha=0.3)
    for i in range(len(df_en)):
        axes[0, 0].annotate(f"{df_en.loc[i, 'Accuracy@50(%)']:.2f}%", 
                           (df_en.loc[i, 'Num Tables'], df_en.loc[i, 'Accuracy@50(%)']),
                           textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)
    
    # 2. Hash Bits vs Accuracy (Key Finding!)
    axes[0, 1].plot(df_en['Hash Bits'], df_en['Accuracy@50(%)'], 'o-', linewidth=2, markersize=10, color='#FF6B6B')
    axes[0, 1].set_xlabel('Hash Bits', fontsize=11, fontweight='bold')
    axes[0, 1].set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
    axes[0, 1].set_title('Hash Bits vs Accuracy (Negative Correlation!)', fontsize=12, fontweight='bold')
    axes[0, 1].grid(True, alpha=0.3)
    axes[0, 1].invert_xaxis()
    for i in range(len(df_en)):
        axes[0, 1].annotate(f"{df_en.loc[i, 'Accuracy@50(%)']:.2f}%", 
                           (df_en.loc[i, 'Hash Bits'], df_en.loc[i, 'Accuracy@50(%)']),
                           textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)
    axes[0, 1].text(0.5, 0.95, '⚠️ Key Finding: Smaller hash bits → Higher accuracy!', 
                   transform=axes[0, 1].transAxes, ha='center', va='top',
                   fontsize=10, bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.5))
    
    # 3. Probes vs Accuracy
    axes[1, 0].plot(df_en['Probes'], df_en['Accuracy@50(%)'], 'o-', linewidth=2, markersize=10, color='#45B7D1')
    axes[1, 0].set_xlabel('Number of Probes (Multi-Probe)', fontsize=11, fontweight='bold')
    axes[1, 0].set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
    axes[1, 0].set_title('Number of Probes vs Accuracy', fontsize=12, fontweight='bold')
    axes[1, 0].grid(True, alpha=0.3)
    for i in range(len(df_en)):
        axes[1, 0].annotate(f"{df_en.loc[i, 'Accuracy@50(%)']:.2f}%", 
                           (df_en.loc[i, 'Probes'], df_en.loc[i, 'Accuracy@50(%)']),
                           textcoords="offset points", xytext=(0,10), ha='center', fontsize=9)
    
    # 4. Performance comparison table
    axes[1, 1].axis('off')
    table_data = []
    for i in range(len(df_en)):
        table_data.append([
            df_en.loc[i, 'Config'].replace('\n', ' '),
            f"{df_en.loc[i, 'Accuracy@50(%)']:.2f}%",
            f"{df_en.loc[i, 'Query Time(ms)']:.2f} ms",
            f"{df_en.loc[i, 'Improvement(%)']:+.2f}%",
            '🏆' if i == best_idx else ''
        ])
    
    table = axes[1, 1].table(cellText=table_data,
                            colLabels=['Config', 'Accuracy', 'Query Time', 'Improvement', ''],
                            cellLoc='center',
                            loc='center',
                            bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 2)
    
    for i in range(5):
        table[(0, i)].set_facecolor('#4ECDC4')
        table[(0, i)].set_text_props(weight='bold', color='white')
    
    for i in range(5):
        table[(best_idx + 1, i)].set_facecolor('#FFE66D')
    
    axes[1, 1].set_title('Detailed Performance Comparison', fontsize=12, fontweight='bold', pad=20)
    
    plt.suptitle('LSH Parameter Impact Trend Analysis', fontsize=16, fontweight='bold', y=0.98)
    plt.tight_layout()
    
    plt.savefig('results/optimization/lsh_parameter_trends_en.png', 
               dpi=300, bbox_inches='tight', facecolor='white')
    print("✓ Saved: results/optimization/lsh_parameter_trends_en.png")
    
    # ========================================================================
    # 图3: 候选集大小分析（英文版）- 回答用户问题的关键图表！
    # ========================================================================
    if candidate_df is not None:
        fig3 = plt.figure(figsize=(18, 12))
        
        # 3.1 候选集大小 vs 准确率
        ax1 = plt.subplot(2, 3, 1)
        scatter1 = ax1.scatter(candidate_df['candidate_ratio'], candidate_df['accuracy'],
                              s=300, c=colors, alpha=0.6, edgecolors='black', linewidth=2)
        for i, row in candidate_df.iterrows():
            ax1.annotate(row['config'], (row['candidate_ratio'], row['accuracy']),
                        fontsize=8, ha='center', va='bottom')
        ax1.set_xlabel('Candidate Set Size (% of dataset)', fontsize=11, fontweight='bold')
        ax1.set_ylabel('Accuracy@50 (%)', fontsize=11, fontweight='bold')
        ax1.set_title('Candidate Set Size vs Accuracy', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # 3.2 候选集大小 vs 查询时间
        ax2 = plt.subplot(2, 3, 2)
        scatter2 = ax2.scatter(candidate_df['candidate_ratio'], candidate_df['query_time'],
                              s=300, c=colors, alpha=0.6, edgecolors='black', linewidth=2)
        for i, row in candidate_df.iterrows():
            ax2.annotate(row['config'], (row['candidate_ratio'], row['query_time']),
                        fontsize=8, ha='center', va='bottom')
        ax2.set_xlabel('Candidate Set Size (% of dataset)', fontsize=11, fontweight='bold')
        ax2.set_ylabel('Query Time (ms)', fontsize=11, fontweight='bold')
        ax2.set_title('Candidate Set Size vs Query Time', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        # 标注50%阈值线（用户关心的临界点）
        ax2.axvline(x=50, color='red', linestyle='--', linewidth=2, alpha=0.5, 
                   label='50% Threshold (LSH slowdown risk)')
        ax2.legend(fontsize=9)
        
        # 3.3 候选集大小分布柱状图
        ax3 = plt.subplot(2, 3, 3)
        bars = ax3.bar(range(len(candidate_df)), candidate_df['candidate_ratio'], 
                      color=colors, alpha=0.8, edgecolor='black')
        ax3.set_xticks(range(len(candidate_df)))
        ax3.set_xticklabels([c.replace('\n', ' ') for c in candidate_df['config']], 
                           rotation=15, ha='right', fontsize=8)
        ax3.set_ylabel('Candidate Set Size (%)', fontsize=11, fontweight='bold')
        ax3.set_title('Candidate Set Size Distribution', fontsize=12, fontweight='bold')
        ax3.axhline(y=50, color='red', linestyle='--', linewidth=2, alpha=0.5)
        ax3.grid(axis='y', alpha=0.3)
        
        for i, bar in enumerate(bars):
            height = bar.get_height()
            ax3.text(bar.get_x() + bar.get_width()/2., height,
                    f'{height:.1f}%', ha='center', va='bottom', fontsize=9, fontweight='bold')
        
        # 3.4 效率分析: 准确率/候选集大小
        ax4 = plt.subplot(2, 3, 4)
        efficiency = candidate_df['accuracy'] / candidate_df['candidate_ratio']
        bars = ax4.bar(range(len(candidate_df)), efficiency, color=colors, alpha=0.8, edgecolor='black')
        ax4.set_xticks(range(len(candidate_df)))
        ax4.set_xticklabels([c.replace('\n', ' ') for c in candidate_df['config']], 
                           rotation=15, ha='right', fontsize=8)
        ax4.set_ylabel('Efficiency (Accuracy / Candidate %)', fontsize=11, fontweight='bold')
        ax4.set_title('LSH Efficiency Analysis', fontsize=12, fontweight='bold')
        ax4.grid(axis='y', alpha=0.3)
        
        for i, bar in enumerate(bars):
            height = bar.get_height()
            ax3.text(bar.get_x() + bar.get_width()/2., height,
                    f'{height:.2f}', ha='center', va='bottom', fontsize=9)
        
        # 3.5 候选集大小详细数据表
        ax5 = plt.subplot(2, 3, 5)
        ax5.axis('off')
        table_data = []
        for i, row in candidate_df.iterrows():
            table_data.append([
                row['config'].replace('\n', ' '),
                f"{row['avg_candidate_size']:.0f}",
                f"{row['candidate_ratio']:.1f}%",
                f"{row['accuracy']:.2f}%",
                f"{row['query_time']:.2f} ms"
            ])
        
        table = ax5.table(cellText=table_data,
                         colLabels=['Config', 'Avg Cand.\nSize', 'Cand.\nRatio', 'Accuracy', 'Query\nTime'],
                         cellLoc='center',
                         loc='center',
                         bbox=[0, 0, 1, 1])
        table.auto_set_font_size(False)
        table.set_fontsize(8)
        table.scale(1, 2)
        
        for i in range(5):
            table[(0, i)].set_facecolor('#4ECDC4')
            table[(0, i)].set_text_props(weight='bold', color='white')
        
        ax5.set_title('Candidate Set Detailed Statistics', fontsize=12, fontweight='bold', pad=20)
        
        # 3.6 关键发现总结
        ax6 = plt.subplot(2, 3, 6)
        ax6.axis('off')
        
        # 计算关键指标
        max_ratio = candidate_df['candidate_ratio'].max()
        min_ratio = candidate_df['candidate_ratio'].min()
        avg_ratio = candidate_df['candidate_ratio'].mean()
        
        over_50_configs = candidate_df[candidate_df['candidate_ratio'] > 50]
        
        findings_text = f"""
KEY FINDINGS:

📊 Candidate Set Size Analysis:
  • Min: {min_ratio:.1f}%
  • Max: {max_ratio:.1f}%
  • Avg: {avg_ratio:.1f}%

⚠️ Performance Impact:
  • Configs with >50% candidates: {len(over_50_configs)}
  • LSH becomes slower due to:
    - Hash computation overhead
    - Candidate aggregation cost
    
✅ Recommendations:
  1. Keep candidate set < 50% of dataset
  2. Use smaller hash bits for better 
     bucket distribution
  3. Balance #tables vs hash bits
  4. Multi-probe helps but increases
     candidate set size
        """
        
        ax6.text(0.1, 0.95, findings_text, transform=ax6.transAxes,
                fontsize=10, verticalalignment='top', family='monospace',
                bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))
        ax6.set_title('Key Findings & Recommendations', fontsize=12, fontweight='bold', pad=20)
        
        plt.suptitle('LSH Candidate Set Size Analysis - DeepFashion Dataset\n(Answering: Candidate Set Distribution & Performance Relationship)', 
                    fontsize=16, fontweight='bold', y=0.98)
        plt.tight_layout()
        
        plt.savefig('results/optimization/lsh_candidate_set_analysis_en.png', 
                   dpi=300, bbox_inches='tight', facecolor='white')
        print("✓ Saved: results/optimization/lsh_candidate_set_analysis_en.png")
    
    plt.show()


# ============================================================================
# 主函数：生成所有可视化
# ============================================================================
if __name__ == '__main__':
    # 首先生成中文版本（保持原有功能）
    print("正在生成中文版本...")
    # （原有代码已经在前面执行）
    
    # 生成英文版本
    print("\n" + "="*60)
    print("Generating English Version Visualizations...")
    print("="*60)
    
    # 尝试加载数据并生成候选集分析
    vectors_path = '../../data/data_LY/inshop_clip_vectors_gallery.npy'
    candidate_df = None
    
    if os.path.exists(vectors_path) and LSHIndex is not None:
        try:
            candidate_df = generate_candidate_set_analysis_en(vectors_path)
        except Exception as e:
            print(f"Warning: Could not generate candidate set analysis: {e}")
            candidate_df = None
    
    # 生成所有英文可视化
    visualize_english_version(candidate_df)
    
    print("\n" + "="*60)
    print("✅ All visualizations completed!")
    print("Generated files:")
    print("  Chinese version:")
    print("    1. lsh_optimization_visualization.png")
    print("    2. lsh_parameter_trends.png")
    print("  English version:")
    print("    1. lsh_optimization_visualization_en.png")
    print("    2. lsh_parameter_trends_en.png")
    print("    3. lsh_candidate_set_analysis_en.png (Candidate Set Analysis)")
    print("="*60)

