"""
LSH深度分析与优化脚本
按照修改意见实现桶分布分析、候选集分析、数据特征分析和优化方案
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import time
from typing import Dict, List, Tuple
from collections import defaultdict
from tqdm import tqdm
import os
import sys

# 导入LSH相关类
sys.path.append(os.path.dirname(__file__))
from lsh_search import LSHIndex
from brute_force_search import BruteForceSearch


# ============================================================================
# CODE BLOCK 2.1: LSH BUCKET DISTRIBUTION ANALYSIS FUNCTION
# ============================================================================
def analyze_lsh_bucket_distribution(param_df, vectors):
    """Analyze LSH bucket distribution characteristics"""
    print("\n=== LSH Bucket Distribution Analysis ===")
    
    # 使用最佳配置
    best_config = param_df.loc[param_df['recall_at_10'].idxmax()]
    lsh = LSHIndex(hash_family='random_projection',
                   num_tables=int(best_config['num_tables']),
                   hash_size=int(best_config['hash_size']))
    lsh.build_index(vectors)
    
    # 获取所有桶的大小
    bucket_distribution = [len(bucket) for table in lsh.hash_tables 
                          for bucket in table.values()]
    
    # 统计信息
    stats = {
        'min_bucket_size': np.min(bucket_distribution),
        'max_bucket_size': np.max(bucket_distribution),
        'median_bucket_size': np.median(bucket_distribution),
        'std_bucket_size': np.std(bucket_distribution),
        'empty_buckets_ratio': sum(1 for size in bucket_distribution if size == 0) / len(bucket_distribution),
        'oversized_buckets_ratio': sum(1 for size in bucket_distribution if size > 1000) / len(bucket_distribution)
    }
    
    print(f"Bucket Distribution Statistics:")
    print(f"  Min bucket size: {stats['min_bucket_size']}")
    print(f"  Max bucket size: {stats['max_bucket_size']}")
    print(f"  Median bucket size: {stats['median_bucket_size']:.2f}")
    print(f"  Std bucket size: {stats['std_bucket_size']:.2f}")
    print(f"  Empty buckets ratio: {stats['empty_buckets_ratio']:.2%}")
    print(f"  Oversized buckets (>1000) ratio: {stats['oversized_buckets_ratio']:.2%}")
    
    # 可视化
    os.makedirs('results/analysis', exist_ok=True)
    
    plt.figure(figsize=(12, 5))
    
    # 子图1: 桶大小分布直方图
    plt.subplot(1, 2, 1)
    plt.hist(bucket_distribution, bins=50, edgecolor='black')
    plt.xlabel('Bucket Size')
    plt.ylabel('Frequency')
    plt.title('LSH Bucket Size Distribution')
    plt.yscale('log')
    
    # 子图2: 桶大小百分位数
    plt.subplot(1, 2, 2)
    percentiles = [50, 75, 90, 95, 99]
    values = [np.percentile(bucket_distribution, p) for p in percentiles]
    plt.bar(range(len(percentiles)), values)
    plt.xticks(range(len(percentiles)), [f'P{p}' for p in percentiles])
    plt.ylabel('Bucket Size')
    plt.title('Bucket Size Percentiles')
    
    plt.tight_layout()
    plt.savefig('results/analysis/bucket_distribution.png', dpi=300)
    plt.close()
    
    return stats


# ============================================================================
# CODE BLOCK 2.2: CANDIDATE SET SIZE VS PERFORMANCE ANALYSIS FUNCTION
# ============================================================================
def analyze_candidate_set_performance(param_df, vectors, labels=None):
    """Analyze relationship between candidate set size and performance"""
    print("\n=== Candidate Set Size vs Performance Analysis ===")
    
    results = []
    test_queries = vectors[np.random.choice(len(vectors), 100, replace=False)]
    
    for _, config in param_df.iterrows():
        lsh = LSHIndex(hash_family='random_projection',
                      num_tables=int(config['num_tables']),
                      hash_size=int(config['hash_size']))
        lsh.build_index(vectors)
        
        candidate_sizes, query_times = [], []
        
        for query in test_queries:
            start = time.time()
            candidates = lsh._get_candidates(query)  # 调用LSHIndex的_get_candidates方法
            query_time = (time.time() - start) * 1000
            candidate_sizes.append(len(candidates))
            query_times.append(query_time)
        
        results.append({
            'num_tables': config['num_tables'],
            'hash_size': config['hash_size'],
            'avg_candidate_size': np.mean(candidate_sizes),
            'std_candidate_size': np.std(candidate_sizes),
            'avg_query_time': np.mean(query_times),
            'recall': config.get('recall_at_10', 0)
        })
    
    df = pd.DataFrame(results)
    
    # 可视化
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    # 候选集大小 vs 查询时间
    axes[0].scatter(df['avg_candidate_size'], df['avg_query_time'],
                   c=df['num_tables'], cmap='viridis', s=100, alpha=0.6)
    axes[0].set_xlabel('Average Candidate Set Size')
    axes[0].set_ylabel('Average Query Time (ms)')
    axes[0].set_title('Candidate Set Size vs Query Time')
    
    # 候选集大小 vs 召回率
    axes[1].scatter(df['avg_candidate_size'], df['recall'],
                   c=df['hash_size'], cmap='plasma', s=100, alpha=0.6)
    axes[1].set_xlabel('Average Candidate Set Size')
    axes[1].set_ylabel('Recall@10 (%)')
    axes[1].set_title('Candidate Set Size vs Recall')
    
    # 召回率 vs 查询时间的权衡
    axes[2].scatter(df['recall'], df['avg_query_time'],
                   c=df['avg_candidate_size'], cmap='coolwarm', s=100, alpha=0.6)
    axes[2].set_xlabel('Recall@10 (%)')
    axes[2].set_ylabel('Average Query Time (ms)')
    axes[2].set_title('Recall-Speed Tradeoff')
    
    plt.tight_layout()
    plt.savefig('results/analysis/candidate_set_analysis.png', dpi=300)
    plt.close()
    
    return df


# ============================================================================
# CODE BLOCK 2.3: DATA CHARACTERISTICS IMPACT ANALYSIS FUNCTION
# ============================================================================
def analyze_data_characteristics_impact(vectors):
    """Analyze how data characteristics affect LSH performance"""
    print("\n=== Data Characteristics Impact Analysis ===")
    
    # 计算数据特征
    norms = np.linalg.norm(vectors, axis=1)
    
    # 采样计算成对距离
    pairwise_distances = []
    sample_size = min(1000, len(vectors))
    sample_indices = np.random.choice(len(vectors), sample_size, replace=False)
    
    for i in range(0, len(sample_indices), 10):
        distances = np.linalg.norm(vectors - vectors[sample_indices[i]], axis=1)
        pairwise_distances.extend(distances[:100])
    
    characteristics = {
        'vector_dimension': vectors.shape[1],
        'num_vectors': len(vectors),
        'avg_norm': np.mean(norms),
        'std_norm': np.std(norms),
        'avg_pairwise_distance': np.mean(pairwise_distances),
        'std_pairwise_distance': np.std(pairwise_distances)
    }
    
    print(f"Data Characteristics:")
    print(f"  Dimension: {characteristics['vector_dimension']}")
    print(f"  Count: {characteristics['num_vectors']}")
    print(f"  Avg Norm: {characteristics['avg_norm']:.2f}")
    print(f"  Std Norm: {characteristics['std_norm']:.2f}")
    print(f"  Avg Pairwise Distance: {characteristics['avg_pairwise_distance']:.2f}")
    print(f"  Std Pairwise Distance: {characteristics['std_pairwise_distance']:.2f}")
    
    # 可视化
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    
    # 向量范数分布
    axes[0].hist(norms, bins=50, edgecolor='black', alpha=0.7)
    axes[0].set_xlabel('Vector Norm')
    axes[0].set_ylabel('Frequency')
    axes[0].set_title('Vector Norm Distribution')
    
    # 成对距离分布
    axes[1].hist(pairwise_distances, bins=50, edgecolor='black', alpha=0.7)
    axes[1].set_xlabel('Pairwise Distance')
    axes[1].set_ylabel('Frequency')
    axes[1].set_title('Pairwise Distance Distribution')
    
    # 数据特征文本显示
    axes[2].text(0.1, 0.9, f"Dimension: {characteristics['vector_dimension']}", 
                transform=axes[2].transAxes)
    axes[2].text(0.1, 0.8, f"Count: {characteristics['num_vectors']:,}", 
                transform=axes[2].transAxes)
    axes[2].text(0.1, 0.7, f"Avg Norm: {characteristics['avg_norm']:.2f}", 
                transform=axes[2].transAxes)
    axes[2].text(0.1, 0.6, f"Avg Dist: {characteristics['avg_pairwise_distance']:.2f}", 
                transform=axes[2].transAxes)
    axes[2].axis('off')
    axes[2].set_title('Data Characteristics')
    
    plt.tight_layout()
    plt.savefig('results/analysis/data_characteristics.png', dpi=300)
    plt.close()
    
    return characteristics


# ============================================================================
# CODE BLOCK 3.3: BUCKET SIZE BALANCING
# ============================================================================
class LSHIndexBalanced(LSHIndex):
    """LSH with bucket size balancing"""
    
    def build_index_with_balancing(self, vectors: np.ndarray, max_bucket_size=500):
        """构建带有桶大小限制的LSH索引"""
        print(f"Building LSH index with bucket balancing (max size: {max_bucket_size})...")
        
        self.vectors = vectors.astype(np.float32)
        dim = vectors.shape[1]
        
        # 生成哈希函数
        if self.hash_family == 'random_projection':
            self.hash_functions = self._generate_random_projection_functions(dim)
        
        # 初始化哈希表
        self.hash_tables = [defaultdict(list) for _ in range(self.num_tables)]
        overflow_vectors = []
        
        # 对每个向量进行哈希并插入到表中
        for idx, vector in enumerate(tqdm(vectors, desc="Hashing with balancing")):
            inserted = False
            
            for table_idx in range(self.num_tables):
                hash_key = self._hash_vector_random_projection(vector, table_idx)
                
                # 检查桶大小限制
                if len(self.hash_tables[table_idx][hash_key]) < max_bucket_size:
                    self.hash_tables[table_idx][hash_key].append(idx)
                    inserted = True
                    break
            
            # 如果所有桶都满了，加入溢出列表
            if not inserted:
                overflow_vectors.append(idx)
        
        # 处理溢出向量
        if overflow_vectors:
            print(f"Creating secondary storage for {len(overflow_vectors)} overflow vectors")
            self.overflow_vectors = set(overflow_vectors)  # 存储溢出向量的索引
        else:
            self.overflow_vectors = set()
        
        self.is_built = True
        
        # 打印统计
        total_buckets = sum(len(table) for table in self.hash_tables)
        avg_bucket_size = np.mean([len(bucket) for table in self.hash_tables 
                                   for bucket in table.values()])
        max_actual_bucket = max([len(bucket) for table in self.hash_tables 
                                for bucket in table.values()])
        
        print(f"Total buckets: {total_buckets}")
        print(f"Average bucket size: {avg_bucket_size:.2f}")
        print(f"Max bucket size: {max_actual_bucket}")
        print(f"Overflow vectors: {len(overflow_vectors)}")
        
        return {
            'total_buckets': total_buckets,
            'avg_bucket_size': avg_bucket_size,
            'max_bucket_size': max_actual_bucket,
            'overflow_count': len(overflow_vectors)
        }
    
    def search_with_overflow(self, query_vectors: np.ndarray, k: int = 10, 
                            metric: str = 'cosine') -> Tuple[np.ndarray, np.ndarray]:
        """执行搜索（包含溢出向量处理）"""
        if not self.is_built:
            raise ValueError("Index not built. Call build_index_with_balancing() first.")
        
        all_distances = []
        all_indices = []
        
        for query_vector in tqdm(query_vectors, desc="Searching with overflow"):
            # 1. 获取常规候选集
            candidates = self._get_candidates(query_vector)
            
            # 2. 添加部分溢出向量（随机采样）
            if self.overflow_vectors:
                overflow_sample_size = min(k * 2, len(self.overflow_vectors))
                overflow_sample = np.random.choice(list(self.overflow_vectors), 
                                                  overflow_sample_size, replace=False)
                candidates.update(overflow_sample)
            
            if len(candidates) == 0:
                candidates = set(np.random.choice(len(self.vectors), min(k*2, len(self.vectors)), 
                                                 replace=False))
            
            # 3. 计算候选向量的精确距离
            candidate_list = list(candidates)
            candidate_vectors = self.vectors[candidate_list]
            
            if metric == 'cosine':
                query_norm = query_vector / (np.linalg.norm(query_vector) + 1e-8)
                candidate_norms = candidate_vectors / (np.linalg.norm(candidate_vectors, axis=1, keepdims=True) + 1e-8)
                similarities = candidate_norms @ query_norm
                distances = 1 - similarities
            else:  # euclidean
                distances = np.linalg.norm(candidate_vectors - query_vector, axis=1)
            
            # 4. 选择top-k
            if len(distances) > k:
                top_k_idx = np.argpartition(distances, k)[:k]
                top_k_idx = top_k_idx[np.argsort(distances[top_k_idx])]
            else:
                top_k_idx = np.argsort(distances)
            
            result_indices = [candidate_list[i] for i in top_k_idx]
            result_distances = distances[top_k_idx]
            
            # 5. 补充到k个结果
            while len(result_indices) < k:
                random_idx = np.random.randint(0, len(self.vectors))
                if random_idx not in result_indices:
                    result_indices.append(random_idx)
                    if metric == 'cosine':
                        query_norm = query_vector / (np.linalg.norm(query_vector) + 1e-8)
                        vec_norm = self.vectors[random_idx] / (np.linalg.norm(self.vectors[random_idx]) + 1e-8)
                        sim = np.dot(query_norm, vec_norm)
                        dist = 1 - sim
                    else:
                        dist = np.linalg.norm(self.vectors[random_idx] - query_vector)
                    result_distances = np.append(result_distances, dist)
            
            all_distances.append(result_distances[:k])
            all_indices.append(result_indices[:k])
        
        return np.array(all_distances), np.array(all_indices)


# ============================================================================
# 主评估函数
# ============================================================================
def run_deep_analysis(vectors_path: str, dataset_name: str):
    """运行完整的深度分析"""
    
    print(f"\n{'='*60}")
    print(f"LSH深度分析 - {dataset_name}")
    print(f"{'='*60}")
    
    # 加载数据
    vectors = np.load(vectors_path)
    print(f"Loaded {len(vectors)} vectors of dimension {vectors.shape[1]}")
    
    # 生成参数网格用于分析
    param_grid = []
    for num_tables in [5, 10, 15, 20]:
        for hash_size in [8, 10, 12, 14]:
            param_grid.append({
                'num_tables': num_tables,
                'hash_size': hash_size
            })
    
    # 快速参数测试
    print("\n测试不同参数配置...")
    test_queries = vectors[np.random.choice(len(vectors), 100, replace=False)]
    
    param_results = []
    for params in tqdm(param_grid, desc="Testing parameters"):
        lsh = LSHIndex(hash_family='random_projection', **params)
        lsh.build_index(vectors)
        
        start = time.time()
        _, _ = lsh.search(test_queries, k=10, metric='cosine')
        query_time = ((time.time() - start) / len(test_queries)) * 1000
        
        stats = lsh.get_stats()
        param_results.append({
            'num_tables': params['num_tables'],
            'hash_size': params['hash_size'],
            'avg_query_time_ms': query_time,
            'avg_bucket_size': stats['avg_bucket_size'],
            'max_bucket_size': stats['max_bucket_size'],
            'recall_at_10': 100.0  # 占位符
        })
    
    param_df = pd.DataFrame(param_results)
    
    # 执行分析
    print("\n" + "="*60)
    print("Part 2: 深度分析")
    print("="*60)
    
    # 2.1 桶分布分析
    bucket_stats = analyze_lsh_bucket_distribution(param_df, vectors)
    
    # 2.2 候选集分析
    candidate_df = analyze_candidate_set_performance(param_df, vectors)
    
    # 2.3 数据特征分析
    data_chars = analyze_data_characteristics_impact(vectors)
    
    # Part 3: 测试优化方案
    print("\n" + "="*60)
    print("Part 3: 桶大小平衡优化测试")
    print("="*60)
    
    # 使用最佳参数测试优化
    best_config = param_df.loc[param_df['avg_bucket_size'].idxmin()]
    
    # 原始LSH
    print("\n--- 原始LSH ---")
    lsh_original = LSHIndex(hash_family='random_projection',
                           num_tables=int(best_config['num_tables']),
                           hash_size=int(best_config['hash_size']))
    lsh_original.build_index(vectors)
    
    start = time.time()
    dist_orig, idx_orig = lsh_original.search(test_queries, k=50, metric='cosine')
    time_orig = ((time.time() - start) / len(test_queries)) * 1000
    
    # 优化的LSH
    print("\n--- 优化的LSH (桶大小限制=500) ---")
    lsh_balanced = LSHIndexBalanced(hash_family='random_projection',
                                    num_tables=int(best_config['num_tables']),
                                    hash_size=int(best_config['hash_size']))
    balance_stats = lsh_balanced.build_index_with_balancing(vectors, max_bucket_size=500)
    
    start = time.time()
    dist_bal, idx_bal = lsh_balanced.search_with_overflow(test_queries, k=50, metric='cosine')
    time_bal = ((time.time() - start) / len(test_queries)) * 1000
    
    # 暴力搜索作为ground truth
    print("\n--- Brute Force (Ground Truth) ---")
    bf = BruteForceSearch(metric='cosine')
    bf.build_index(vectors)
    dist_bf, idx_bf = bf.search(test_queries, k=50)
    
    # 计算准确率
    def calculate_accuracy(pred_indices, true_indices, k=50):
        total_correct = 0
        for i in range(len(pred_indices)):
            gt_set = set(true_indices[i][:k])
            pred_set = set(pred_indices[i][:k])
            total_correct += len(gt_set.intersection(pred_set))
        return (total_correct / (len(pred_indices) * k)) * 100
    
    acc_orig = calculate_accuracy(idx_orig, idx_bf, k=50)
    acc_bal = calculate_accuracy(idx_bal, idx_bf, k=50)
    
    print(f"\n{'='*60}")
    print("优化效果对比")
    print(f"{'='*60}")
    print(f"原始LSH:")
    print(f"  查询时间: {time_orig:.2f} ms")
    print(f"  准确率@50: {acc_orig:.2f}%")
    print(f"  平均桶大小: {best_config['avg_bucket_size']:.2f}")
    print(f"\n优化LSH (桶平衡):")
    print(f"  查询时间: {time_bal:.2f} ms")
    print(f"  准确率@50: {acc_bal:.2f}%")
    print(f"  平均桶大小: {balance_stats['avg_bucket_size']:.2f}")
    print(f"  最大桶大小: {balance_stats['max_bucket_size']}")
    print(f"  溢出向量数: {balance_stats['overflow_count']}")
    print(f"\n准确率提升: {acc_bal - acc_orig:+.2f}%")
    print(f"时间变化: {time_bal - time_orig:+.2f} ms ({((time_bal/time_orig - 1)*100):+.1f}%)")
    
    # 生成最终报告
    report = []
    report.append(f"# LSH深度分析报告 - {dataset_name}\n")
    report.append(f"## 数据集信息\n")
    report.append(f"- 向量数量: {len(vectors):,}\n")
    report.append(f"- 向量维度: {vectors.shape[1]}\n")
    report.append(f"- 平均范数: {data_chars['avg_norm']:.2f}\n")
    report.append(f"- 平均成对距离: {data_chars['avg_pairwise_distance']:.2f}\n\n")
    
    report.append(f"## 桶分布分析\n")
    report.append(f"- 最小桶大小: {bucket_stats['min_bucket_size']}\n")
    report.append(f"- 最大桶大小: {bucket_stats['max_bucket_size']}\n")
    report.append(f"- 中位桶大小: {bucket_stats['median_bucket_size']:.2f}\n")
    report.append(f"- 桶大小标准差: {bucket_stats['std_bucket_size']:.2f}\n")
    report.append(f"- 空桶比例: {bucket_stats['empty_buckets_ratio']:.2%}\n")
    report.append(f"- 超大桶(>1000)比例: {bucket_stats['oversized_buckets_ratio']:.2%}\n\n")
    
    report.append(f"## 优化效果\n")
    report.append(f"### 原始LSH\n")
    report.append(f"- 查询时间: {time_orig:.2f} ms\n")
    report.append(f"- 准确率@50: {acc_orig:.2f}%\n\n")
    report.append(f"### 优化LSH (桶大小限制=500)\n")
    report.append(f"- 查询时间: {time_bal:.2f} ms\n")
    report.append(f"- 准确率@50: {acc_bal:.2f}%\n")
    report.append(f"- 准确率提升: {acc_bal - acc_orig:+.2f}%\n")
    report.append(f"- 时间变化: {((time_bal/time_orig - 1)*100):+.1f}%\n\n")
    
    report.append(f"## 结论\n")
    if acc_bal > acc_orig:
        report.append(f"✅ 桶大小平衡优化**有效提升**了准确率 ({acc_bal - acc_orig:+.2f}%)\n")
    else:
        report.append(f"⚠️ 桶大小平衡优化对准确率提升有限\n")
    
    if bucket_stats['max_bucket_size'] > 1000:
        report.append(f"⚠️ 发现严重的数据倾斜问题：最大桶大小达到 {bucket_stats['max_bucket_size']}\n")
        report.append(f"建议：\n")
        report.append(f"1. 使用更大的hash_size以增加桶的数量\n")
        report.append(f"2. 使用多个哈希表以提高覆盖率\n")
        report.append(f"3. 考虑使用其他索引方法（如FAISS IVF）\n")
    
    # 保存报告
    os.makedirs('reports', exist_ok=True)
    report_path = f'reports/lsh_deep_analysis_{dataset_name}.md'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.writelines(report)
    
    print(f"\n报告已保存到: {report_path}")
    
    return {
        'bucket_stats': bucket_stats,
        'data_characteristics': data_chars,
        'original_accuracy': acc_orig,
        'balanced_accuracy': acc_bal,
        'original_time': time_orig,
        'balanced_time': time_bal
    }


if __name__ == '__main__':
    # 测试DeepFashion数据集
    deepfashion_path = '../../data/data_LY/inshop_clip_vectors_gallery.npy'
    
    if os.path.exists(deepfashion_path):
        results = run_deep_analysis(deepfashion_path, 'DeepFashion')
    else:
        print(f"数据文件未找到: {deepfashion_path}")

